<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/check_expiry.php';
?>